#load libraries
library(ggplot2)
library(dplyr)

#Read data into R
data_1 <- read.csv("~/work/Survey_1.csv", header = TRUE, strip.white=TRUE)

#get all row with yes.

cleaned_data <- filter(data_1, Do.you.wish.to.participate.in.this.assessment. == "Yes")
View(cleaned_data)

#rename several coloumns
cleaned_data = rename(cleaned_data,position = X3..What.is.your.current.position)
cleaned_data = rename(cleaned_data,conset = Do.you.wish.to.participate.in.this.assessment.)
cleaned_data = rename(cleaned_data,department = X1..Which.Department.do.you.belong.to.)
cleaned_data = rename(cleaned_data,unit = X2..Which.Unit.do.you.belong.to.)
cleaned_data = select(cleaned_data, -If.you.belong.to.another.department...Kindly.specify.here.)
cleaned_data = select(cleaned_data, -If.you.belong.to.another.Unit...Kindly.specify.here.)

#experience variables
cleaned_data = rename(cleaned_data,time_current = X4..How.long.have.you.been.in.your.current.position..In.months.)
cleaned_data = rename(cleaned_data,time_industry = X5..Experience.in.your.current.area.of.work..In.months.)
#level of education
cleaned_data = rename(cleaned_data,level_education = X6..Highest.level.of.education..Specify.level.of.training.and.actual.area.of.training.)
#training data
cleaned_data = rename(cleaned_data,training = X7..Have.you.done.any.training.in.your.current.area.of.work.)

#count Unique departments
by_department = group_by(cleaned_data, department)
unique_dpt = summarise(by_department, count = n())

#create a bar plot
ggplot(unique_dpt, aes(department, count, fill = department))+
  geom_bar(stat = "identity")+
  geom_text(aes(label = count), fontface = "bold")+
  theme(
    axis.text.x = element_blank(),
    axis.title.x = element_blank(),
    axis.ticks.x = element_blank(),
    axis.text.y=element_text(colour = "#7F7F7F", size = 12, face = "bold"),
    axis.title.y = element_text(colour = "#FE6F88", size = 12, face = "bold"),
    legend.title = element_text(colour = "#FE6F88", size = 12, face = "bold"),
    legend.text = element_text(colour = "#7F7F7F", size = 9, face = "bold")
  )


#count Unique unit
by_unit = group_by(cleaned_data, unit)
unique_unit = summarise(by_unit, count = n())

#create a bar plot
ggplot(unique_unit, aes(unit, count, fill = unit))+
  geom_bar(stat = "identity")+
  geom_text(aes(label = count), fontface = "bold")+
  theme(
    axis.text.x = element_blank(),
    axis.title.x = element_blank(),
    axis.ticks.x = element_blank(),
    axis.text.y=element_text(colour = "#7F7F7F", size = 12, face = "bold"),
    axis.title.y = element_text(colour = "#FE6F88", size = 12, face = "bold"),
    legend.title = element_text(colour = "#FE6F88", size = 12, face = "bold"),
    legend.text = element_text(colour = "#7F7F7F", size = 9, face = "bold")
  )

#Analysis of unique positions reported back in the survey.
cleaned_data$position <- tolower(cleaned_data$position)

# returns string w/o trailing whitespace
trim.trailing <- function (x) sub("\\s+$", "", x)

cleaned_data$position <-trim.trailing(cleaned_data$position)

by_position = group_by(cleaned_data, position)
unique_position = summarise(by_position, count = n())

#table actual positions reported

#How long have you been in your current position
#Develop a box plot
bxplt_data_1 <- data.frame(group = "current", value = cleaned_data$time_current)
bxplt_data_2 <- data.frame(group = "industry", value = cleaned_data$time_industry)
bxplt_data <- rbind(bxplt_data_1,bxplt_data_2)

#develop a box plot for distribution of experience
ggplot(data = bxplt_data, aes(group, value, fill = group))+
  geom_boxplot(outlier.colour="red", outlier.shape=8,outlier.size=4)


#Analysis of unique qualifications  reported back in the survey.
cleaned_data$level_education <- tolower(cleaned_data$level_education)
cleaned_data$level_education <-trim.trailing(cleaned_data$level_education)
by_edlevel = group_by(cleaned_data, level_education)
unique_edlevel = summarise(by_edlevel, count = n())

#Analysis on training required per unit
training_data <- cleaned_data[,c('training', 'unit')]
grouped_training = group_by(training_data, training)
#unit per training

